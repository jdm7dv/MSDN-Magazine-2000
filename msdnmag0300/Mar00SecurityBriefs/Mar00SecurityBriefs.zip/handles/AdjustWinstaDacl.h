// borrowed from cmdasuser
void _grantSessionSIDAccessToWinstationAndDesktop( HANDLE htok, bool bGrant );
