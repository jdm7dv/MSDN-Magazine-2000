//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by handles.rc
//
#define IDR_DIRECT                      401
#define IDR_NAMEDOBJECT                 402
#define IDR_INHERITANCE                 404
#define IDR_DUPDINHERITANCE             405
#define IDC_AUTHORITY                   1000
#define IDC_PRINCIPAL                   1001
#define IDC_PASSWORD                    1002
#define IDC_CROSSPROCESS                1003
#define IDC_CROSSWINSTA                 1004
#define IDC_ALTCRED                     1005
#define IDC_OUTPUT                      1007
#define IDC_DETAILEDOUTPUT              1009
#define IDC_AUDITING                    1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
