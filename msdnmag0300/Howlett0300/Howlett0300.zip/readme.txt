To setup this demo, extract these files to a web called VMLArticle.

If you choose to use your own site name, change the strSitename
variable in Script/xsl.js

VMLArticle
	\ Sales
		\WidgetCorp
	\ Script
	\ xsl