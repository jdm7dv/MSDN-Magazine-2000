//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FolderExt.rc
//
#define IDS_PROJNAME                    100
#define IDR_PROPERTY                    101
#define IDD_NEWFOLDERDLG                102
#define IDD_CUSTOMIZEFOLDER             201
#define IDC_TEXT                        201
#define IDC_FOLDERICON                  202
#define IDC_FOLDERNAME                  203
#define IDC_CHANGEICON                  204
#define IDC_CUSTOMIZE                   206
#define IDB_NEWFOLDER                   206
#define IDC_REMOVE                      207
#define IDB_PROMPT                      207
#define IDC_ICONFILE                    208
#define IDC_CURFOLDER                   209
#define IDC_NEWFOLDER                   210

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        207
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         211
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
