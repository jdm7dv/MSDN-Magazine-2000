// NewFolderDlg.cpp : Implementation of CNewFolderDlg
#include "stdafx.h"
#include "NewFolderDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CNewFolderDlg
