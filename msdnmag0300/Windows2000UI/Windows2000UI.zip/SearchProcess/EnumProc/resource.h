//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EnumProc.rc
//
#define IDB_BITMAP1                     101
#define IDD_DLG                         102
#define IDC_TREE                        1000
#define IDC_SNAPSHOT                    1001
#define IDC_NUMPROC                     1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
