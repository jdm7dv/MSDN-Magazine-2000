BULK INSERT tiger..tgr3606101 FROM 'C:\tiger\tgr36061.f61'
WITH (FORMATFILE = 'C:\tiger\f41.fmt')
