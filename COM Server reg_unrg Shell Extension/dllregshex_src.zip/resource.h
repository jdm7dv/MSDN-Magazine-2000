//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dllregshex.rc
//
#define IDB_INSTALL                     106
#define IDB_UNINSTALL                   107
#define IDB_ABOUT                       123
#define IDI_OCX                         126
#define IDCMD_INSTALL                   40001
#define IDCMD_UNINSTALL                 40002
#define IDS_Q_INSTALL                   40006
#define IDS_ABOUT                       40007
#define IDCMD_ABOUT                     40008
#define IDS_QMI_INSTALL                 40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
