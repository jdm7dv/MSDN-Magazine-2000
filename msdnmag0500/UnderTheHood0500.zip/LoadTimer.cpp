#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <shlwapi.h>

//===========================================================================
bool	ProcessCommandLine(PCSTR pszCmdLine, PSTR pszTargetCmdLine );
__int64	TimeProgram( PSTR pszCmdLine );	// Returns timer units

//===========================================================================
char g_szHelp[] =
"Syntax: LoadTimer <TargetCmdLine> [target args]\n\n"
"Matt Pietrek, <some magazine>, <sometime in 2000>\n\n"
"LoadTimer starts a target process, and times how long it takes to load.\n"
"The process is created suspended, and immediately terminated\n";
//===========================================================================

int main( int argc, char * argv[] )
{
    //=====================================================
    // Get target cmd line
    char szTargetCmdLine[MAX_PATH*2] = { 0 };
    if ( !ProcessCommandLine( GetCommandLine(), szTargetCmdLine ) )
    {
        printf( g_szHelp );
        return 1;
    }
    
	SetPriorityClass( GetCurrentProcess(), REALTIME_PRIORITY_CLASS );


	__int64 tBest = 0;

	for ( unsigned i = 0; i < 30; i++ )
	{
		__int64 t = TimeProgram( szTargetCmdLine );

		if ( t == 0 )	// Check for failure code
			break;

		if ( tBest == 0 )
			tBest = t;
		else if ( t < tBest )
			tBest = t;
	}

	LARGE_INTEGER li;
	QueryPerformanceFrequency( &li );

	DWORD ticks = (DWORD)tBest;

	double timeInSeconds = (double)tBest / li.QuadPart;

	printf( "Fastest time: %I64d ticks, %f seconds\n", tBest, timeInSeconds );
	printf( "Ticks: %u\n", ticks );
	printf( "Ticks/second: %I64d\n", li.QuadPart );
    return 0;
}

__int64	TimeProgram( PSTR pszCmdLine )
{
    PROCESS_INFORMATION pi;
	STARTUPINFO si;
    BOOL bCreateProcessRetValue;
	LARGE_INTEGER timeBefore, timeAfter;

    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);

	QueryPerformanceCounter( &timeBefore );

    bCreateProcessRetValue = CreateProcess( 0, pszCmdLine, 0, 0, FALSE,
											REALTIME_PRIORITY_CLASS, 0, 0,
											&si, &pi );

	if ( !bCreateProcessRetValue )
	{
		printf( "CreateProcess failed\n" );
		return 0;
	}

	WaitForSingleObject( pi.hProcess, INFINITE );

	QueryPerformanceCounter( &timeAfter );

	CloseHandle( pi.hThread );
	CloseHandle( pi.hProcess );

	return timeAfter.QuadPart - timeBefore.QuadPart;
}


//===========================================================================
bool ProcessCommandLine(PCSTR pszCmdLine,       // Cmd line passed to us
                        PSTR pszTargetCmdLine   // What we'll start the target
                        )                       // process with
{
    // cmd line syntax is: ThisExeName [OurArgs] TargetExe [TargetArgs]

    PSTR p = PathGetArgs( pszCmdLine );
    if ( p && *p )
    {
        strcpy( pszTargetCmdLine, p );
        return true;
    }

    return false;
}
