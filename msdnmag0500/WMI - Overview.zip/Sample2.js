// Sample2.js
var locator = new ActiveXObject("WbemScripting.SWbemLocator");
var service = locator.ConnectServer();
var props = service.ExecQuery("SELECT Name,FreeSpace FROM Win32_LogicalDisk");
var f = new Enumerator (props);
for (;!f.atEnd();f.moveNext ())
{
  var p = f.item ();
  WScript.Echo(p.Name + " - " + p.FreeSpace + " - " + p.Size);
}


