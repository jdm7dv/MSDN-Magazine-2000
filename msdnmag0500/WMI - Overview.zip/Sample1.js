// Sample1.js
// Get a locator object
var locator = new ActiveXObject("WbemScripting.SWbemLocator");

// Connect to the default namespace on the current machine
// This can be configured, but is usually 'root\cimv2'
var service = locator.ConnectServer();

// Get an object that describes the Win32_LogicalDisk class
var diskclass = service.Get("Win32_LogicalDisk");

// Get an object that describes the instance of Win32_Logical disk
// for the 'C:' drive
var diskinstance = service.Get("Win32_LogicalDisk.DeviceID=\"C:\"");

// Show free space for C: drive
WScript.Echo(diskinstance.FreeSpace);

// Show all properties and values using an 'Enumerator'
// In VBScript, this can be done with a 'FOR EACH' statement
var f=new Enumerator(diskinstance.Properties_)
for (;!f.atEnd();f.moveNext ())
{
  var prop = f.item();
  WScript.Echo(prop.Name + " = " + prop.Value);
}

