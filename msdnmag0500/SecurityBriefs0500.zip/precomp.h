#pragma warning(disable:4786)

#define UNICODE
#define STRICT
#define _WIN32_WINNT 0x500
#define WINVER 0x500
#include <windows.h>
#include <commctrl.h>
#include <ntsecapi.h>
#define SECURITY_WIN32
#include <security.h>
