//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tktview.rc
//
#define IDI_TKTVIEW                     101
#define IDD_CHOOSE_COLUMNS              102
#define IDR_TKTVIEW_MENU                103
#define IDR_TKTVIEW_ACCEL               106
#define IDD_TKTPROPERTIES               108
#define ID_FILE_PURGE_BY_AUTHORITY      999
#define ID_FILE_EXIT                    40001
#define ID_HELP_ABOUT                   40002
#define ID_VIEW_CHOOSECOLUMNS           40003
#define ID_VIEW_REFRESH                 40004
#define ID_FILE_PURGE_ALL               40005
#define ID_FILE_PURGE_BY_PRINCIPAL      40006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
