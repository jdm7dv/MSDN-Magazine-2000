// ReportView.h
#pragma once

#include <vector>
#include <string>
#include <memory>
#include <string>

class ReportView {
public:
  struct DataProvider {
    virtual ~DataProvider() {}
    virtual int compare(void* pva, void* pvb, int nColumn) { return 0; }
    virtual void doubleClick(void* pvItem) {}
  };

  ReportView(DataProvider* pDataProvider = 0)
    : m_hwndParent(0),
      m_hwnd(0),
      m_hil(0),
      m_columns(),
      m_cColumnsInControl(0),
      m_pDataProvider(pDataProvider),
      m_nItemsAppended(0),
      m_nLastColumnSorted(-1),
      m_bSortAscending(true)
  {}
  ~ReportView();

  bool addColumn(const wchar_t* psz, DWORD fmt, DWORD cx, bool bShownByDefault, bool bCanBeSorted = true);
  bool create(HWND hwndParent, int id, const RECT& rc);
  void resize(const RECT& rc, bool bRepaint = true);
  bool chooseColumns(HINSTANCE hInst, int nDlgResource);
  void clear();
  bool append(const std::vector<std::wstring>& text, void* pCookie);
  void setFocus();
  void* getSelectedItem();

  LRESULT onWM_NOTIFY(NMHDR* pNotifyHeader);

private:
  struct Column {
    Column(const wchar_t* psz, DWORD fmt, DWORD cx, bool bShownByDefault, bool bCanBeSorted);
    std::wstring sText;
    DWORD        fmt;
    DWORD        cx;
    bool         bShown;
    bool         bCanBeSorted;
  };
  typedef std::vector<std::auto_ptr<Column> > ColumnVector;

  struct SortInfo {
    SortInfo(DataProvider& _DataProvider, int _col, bool _ascend)
      : DataProvider(_DataProvider), col(_col), ascend(_ascend)
    {}
    DataProvider& DataProvider;
    int     col;
    bool    ascend;
  };
  static int CALLBACK _compareItems(LPARAM a, LPARAM b, LPARAM lp); 

  bool _insertColumns();
  void _onColumnClick(NMLISTVIEW& lv);
  void _onItemDoubleClick(NMITEMACTIVATE& item);

  static BOOL CALLBACK _chooserDlgProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

  HWND         m_hwndParent;
  HWND         m_hwnd;
  HIMAGELIST   m_hil;
  ColumnVector m_columns;
  int          m_cColumnsInControl;
  DataProvider*      m_pDataProvider;
  int          m_nItemsAppended;
  int          m_nLastColumnSorted;
  bool         m_bSortAscending;
};
