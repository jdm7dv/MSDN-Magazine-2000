#include "precomp.h"
#include "ReportView.h"
#include <windowsx.h>
#include <memory>
using namespace std;

ReportView::Column::Column(const wchar_t* psz, DWORD _fmt,
                           DWORD _cx, bool bShownByDefault, bool bCanBeSorted)
: sText(psz ? psz : L""),
  fmt(_fmt),
  cx(_cx),
  bShown(bShownByDefault),
  bCanBeSorted(bCanBeSorted)
{}

ReportView::~ReportView() {
}

bool ReportView::addColumn(const wchar_t* psz, DWORD fmt, DWORD cx,
                           bool bShownByDefault, bool bCanBeSorted) {
  // add all columns before calling create()
  if (m_hwnd)
    return false;

  bool bOk = true;
  try {
    auto_ptr<Column> spColumn(new Column(psz, fmt, cx,
                                         bShownByDefault,
                                         bCanBeSorted));
    m_columns.push_back(spColumn);    
  }
  catch (const exception&) {
    bOk = false;
  }
  return bOk;
}

bool ReportView::create(HWND hwndParent, int id, const RECT& rc) {
  // don't call this twice
  if (m_hwnd)
    return false;

  m_hwndParent = hwndParent;

  const DWORD grfStyle = WS_CHILD | LVS_REPORT | LVS_SHOWSELALWAYS;
  m_hwnd = CreateWindowEx(0, WC_LISTVIEW, 0, grfStyle,
                              rc.left, rc.top,
                              rc.right - rc.left, rc.bottom - rc.top,
                              hwndParent, reinterpret_cast<HMENU>(id),
                              GetModuleHandle(0), 0);
  if (!m_hwnd)
    return false;

  ListView_SetExtendedListViewStyle(m_hwnd, LVS_EX_FULLROWSELECT);

  if (!_insertColumns()) {
    DestroyWindow(m_hwnd);
    return false;
  }

  ShowWindow(m_hwnd, SW_SHOW);

  return m_hwnd ? TRUE : FALSE;
  
}

void ReportView::resize(const RECT& rc, bool bRepaint) {
  MoveWindow(m_hwnd, rc.left, rc.top,
                     rc.right - rc.left, rc.bottom - rc.top,
                     bRepaint ? TRUE : FALSE);
}

bool ReportView::_insertColumns() {
  for (int i = m_cColumnsInControl - 1; i >= 0; --i)
    ListView_DeleteColumn(m_hwnd, i);
  m_cColumnsInControl = 0;

  int iSubItem = 0;
  for (ColumnVector::iterator it = m_columns.begin(); it != m_columns.end(); ++it) {
    const Column& col = *it->get();
    if (col.bShown) {
      LVCOLUMN lvc = {
        LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH,
        col.fmt,
        col.cx,
        const_cast<wchar_t*>(col.sText.c_str()),
        0,
        iSubItem,
        0, 0
      };
      if (-1 == ListView_InsertColumn(m_hwnd, m_cColumnsInControl, &lvc))
        return false;
      ++m_cColumnsInControl;
    }
    ++iSubItem;
  }
  return true;
}

bool ReportView::chooseColumns(HINSTANCE hInst, int nDlgResource) {
  int nResult = DialogBoxParam(hInst, MAKEINTRESOURCE(nDlgResource),
                               m_hwndParent, _chooserDlgProc,
                               reinterpret_cast<LPARAM>(&m_columns));
  if (IDOK == nResult) {
    _insertColumns();
    m_nLastColumnSorted = -1;
    m_bSortAscending    = true;
    return TRUE;
  }
  return FALSE;
}

void ReportView::clear() {
  ListView_DeleteAllItems(m_hwnd);
  m_nItemsAppended = 0;
}

bool ReportView::append(const std::vector<wstring>& text, void* pCookie) {

  LVITEM item = {
    LVIF_PARAM,
    m_nItemsAppended,
    0, 0, 0, 0, 0, 0,
    reinterpret_cast<LPARAM>(pCookie),
    0
  };
  if (-1 == ListView_InsertItem(m_hwnd, &item))
    return false;

  ColumnVector::const_iterator col_it = m_columns.begin();

  // iSubItem indicates *not* the logical order (which you might expect,
  // given that columns have an iSubItem data member), rather it reflects
  // the physical left-to-right, zero-based order of the columns
  int iSubItem = 0;
  for (vector<wstring>::const_iterator it = text.begin(); it != text.end(); ++it) {
    // sanity check: don't add more text than you've defined columns
    if (col_it == m_columns.end())
      return false;
    if ((*col_it)->bShown) {
      item.mask = LVIF_TEXT;
      item.iSubItem = iSubItem;
      item.pszText = const_cast<wchar_t*>(it->c_str());
      if (!SendMessage(m_hwnd, LVM_SETITEMTEXT, m_nItemsAppended, reinterpret_cast<LPARAM>(&item)))
        return false;
      ++iSubItem;
    }
    ++col_it;
  }

  ++m_nItemsAppended;
  return true;
}

void ReportView::setFocus() {
  SetFocus(m_hwnd);
}

void* ReportView::getSelectedItem() {
  LVITEM item;
  item.mask = LVIF_PARAM;
  item.iItem = ListView_GetNextItem(m_hwnd, -1, LVNI_SELECTED);
  if (-1 == item.iItem)
    return 0;
  if (!ListView_GetItem(m_hwnd, &item))
    return 0;
  return reinterpret_cast<void*>(item.lParam);
}

LRESULT ReportView::onWM_NOTIFY(NMHDR* pNotifyHeader) {
  switch (pNotifyHeader->code) {
  case LVN_COLUMNCLICK:
    _onColumnClick(*reinterpret_cast<NMLISTVIEW*>(pNotifyHeader));
    break;
  case NM_DBLCLK:
    _onItemDoubleClick(*reinterpret_cast<NMITEMACTIVATE*>(pNotifyHeader));
  }
  return 0;
}

void ReportView::_onColumnClick(NMLISTVIEW& lv) {
  if (!m_pDataProvider)
    return;
  
  // lv.iSubItem is *not* the subItem we specified in the column;
  // it is actually the zero-based index of the column
  // in left-to-right order; so we need to look up the column's
  // logical subItem
  const int nColumnIndex = lv.iSubItem;
  LVCOLUMN colInfo;
  colInfo.mask = LVCF_SUBITEM;
  if (!ListView_GetColumn(m_hwnd, lv.iSubItem, &colInfo))
    return;

  const int nColumnToSort = colInfo.iSubItem;
  if (!m_columns[nColumnToSort]->bCanBeSorted)
    return;

  if (m_nLastColumnSorted == nColumnToSort) {
    m_bSortAscending = !m_bSortAscending;
  }
  else {
    m_nLastColumnSorted = nColumnToSort;
    m_bSortAscending    = true;
  }
  SortInfo si(*m_pDataProvider, nColumnToSort, m_bSortAscending);
  ListView_SortItems(m_hwnd, _compareItems, &si);
}

void ReportView::_onItemDoubleClick(NMITEMACTIVATE& activateInfo) {
  LVITEM item;
  item.mask = LVIF_PARAM;
  item.iItem = activateInfo.iItem;
  ListView_GetItem(m_hwnd, &item);
  m_pDataProvider->doubleClick(reinterpret_cast<void*>(item.lParam));
}

int CALLBACK ReportView::_compareItems(LPARAM a, LPARAM b, LPARAM lp) {
  const SortInfo& si = *reinterpret_cast<SortInfo*>(lp);
  int n = si.DataProvider.compare(reinterpret_cast<void*>(a),
                            reinterpret_cast<void*>(b),
                            si.col);
  return si.ascend ? n : -n;
}

BOOL CALLBACK ReportView::_chooserDlgProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  switch (msg) {
    case WM_INITDIALOG: {
      HWND hwndList = GetDlgItem(hwnd, 100);
      SetWindowLongPtr(hwnd, GWL_USERDATA, lp);
      ColumnVector& vec = *reinterpret_cast<ColumnVector*>(lp);
      for (ColumnVector::const_iterator it = vec.begin(); it != vec.end(); ++it) {
        const Column& col = *it->get();
        int n = ListBox_AddString(hwndList, col.sText.c_str());
        if (LB_ERR == n) {
          EndDialog(hwnd, IDCANCEL);
          break;
        }
        ListBox_SetSel(hwndList, col.bShown ? TRUE : FALSE, n);
      }
      return TRUE;
    }
    case WM_COMMAND:
      switch(LOWORD(wp)) {
        case IDOK: {
          HWND hwndList = GetDlgItem(hwnd, 100);
          ColumnVector& vec = *reinterpret_cast<ColumnVector*>(GetWindowLongPtr(hwnd, GWL_USERDATA));
          int n = 0;
          for (ColumnVector::iterator it = vec.begin(); it != vec.end(); ++it) {
            Column& col = *it->get();
            col.bShown = ListBox_GetSel(hwndList, n) ? true : false;
            ++n;
          }
          EndDialog(hwnd, LOWORD(wp));
          return TRUE;
        }
        case IDCANCEL:
          EndDialog(hwnd, LOWORD(wp));
          return TRUE;
      }
  }
  return FALSE;
}
