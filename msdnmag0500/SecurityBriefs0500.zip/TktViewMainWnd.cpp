// TktViewMainWnd.cpp
#include "precomp.h"
#include "TktViewMainWnd.h"
#include "WindowMessageCracker.h"
#include "ReportView.h"
#include "MiscUtils.h"
#include "resource.h"
#include <vector>
using namespace std;

void od(HWND hwnd) {}

struct DataProvider : ReportView::DataProvider {
  DataProvider(TktViewMainWnd& mainWnd) : m_mainWnd(mainWnd) {}
  TktViewMainWnd& m_mainWnd;
  int compare(void* pva, void* pvb, int nColumn) {
    const KERB_TICKET_CACHE_INFO const* pa = reinterpret_cast<KERB_TICKET_CACHE_INFO*>(pva);
    const KERB_TICKET_CACHE_INFO const* pb = reinterpret_cast<KERB_TICKET_CACHE_INFO*>(pvb);
    switch (nColumn) {
    case 0: return ::compare(pa->ServerName,     pb->ServerName);
    case 1: return ::compare(pa->RealmName,      pb->RealmName);
    case 2: return ::compare(pa->StartTime,      pb->StartTime);
    case 3: return ::compare(pa->EndTime,        pb->EndTime);
    case 4: return ::compare(pa->RenewTime,      pb->RenewTime);
    case 5: return ::compare(pa->EncryptionType, pb->EncryptionType);
    }
    return false;
  }
  void doubleClick(void* pvItem) {
    DialogBoxParam(GetModuleHandle(0), MAKEINTRESOURCE(IDD_TKTPROPERTIES),
                   m_mainWnd.m_hwnd, m_mainWnd._ticketPropertiesDlg,
                   reinterpret_cast<LPARAM>(pvItem));
  }
};

LRESULT CALLBACK TktViewMainWnd::wndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  BEGIN_CRACK(TktViewMainWnd)
    CRACK_MSG(WM_CREATE)
    CRACK_MSG(WM_DESTROY)
    CRACK_MSG(WM_SIZE)
    CRACK_MSG(WM_COMMAND)
    CRACK_MSG(WM_NOTIFY)
    CRACK_MSG(WM_SETFOCUS)
    CRACK_MSG(WM_INITMENUPOPUP)
  END_CRACK()
  return DefWindowProc(hwnd, msg, wp, lp);
}

bool TktViewMainWnd::registerClass() {
  WNDCLASSEX wc     = { sizeof wc };
  wc.hbrBackground  = GetSysColorBrush(COLOR_WINDOW);
  wc.hCursor        = LoadCursor(0, IDC_ARROW);
  wc.hIcon          = LoadIcon(GetModuleHandle(0), MAKEINTRESOURCE(IDI_TKTVIEW));
  wc.hIconSm        = wc.hIcon;
  wc.hInstance      = GetModuleHandle(0);
  wc.lpfnWndProc    = wndProc;
  wc.lpszClassName  = L"TktViewMainWnd";
  return RegisterClassEx(&wc) ? true : false;
}

TktViewMainWnd* TktViewMainWnd::create(int nCmdShow) {
  TktViewMainWnd* pWnd = new TktViewMainWnd();
  if (!pWnd)
    return 0;

  if (!pWnd->_connectToLSA())
    return 0;

  HMENU hmenu = LoadMenu(GetModuleHandle(0), MAKEINTRESOURCE(IDR_TKTVIEW_MENU));

  const DWORD grfStyle = WS_OVERLAPPEDWINDOW;
  HWND hwnd = CreateWindowEx(0, L"TktViewMainWnd", L"Ticket Viewer", grfStyle,
                             CW_USEDEFAULT, CW_USEDEFAULT,
                             CW_USEDEFAULT, CW_USEDEFAULT,
                             0, hmenu, GetModuleHandle(0), pWnd);
  if (hwnd) {
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
  }
  else {
    delete pWnd;
    pWnd = 0;
  }
  return pWnd;
}

TktViewMainWnd::~TktViewMainWnd() {
  if (m_pTktCache)
    LsaFreeReturnBuffer(m_pTktCache);
}

bool TktViewMainWnd::_connectToLSA() {
  NTSTATUS s = LsaConnectUntrusted(&m_hLSA);
  if (s) {
    _lsaErrMsg(L"LsaConnectUntrusted", s);
    return false;
  }
  LSA_STRING sKerb;
  _initString(sKerb, MICROSOFT_KERBEROS_NAME_A);
  s = LsaLookupAuthenticationPackage(m_hLSA, &sKerb, &m_nKerbIndex);
  if (s) {
    _errMsg(L"LsaLookupAuthenticationPackage", s);
    return false;
  }
  return true;
}

bool TktViewMainWnd::_setTitle() {
  wchar_t szTitle[1024];
  lstrcpy(szTitle, L"Ticket Viewer: ");
  wchar_t* psz = szTitle + lstrlen(szTitle);

  DWORD cch = 512;
  if (!GetUserNameEx(NameCanonical, psz, &cch)) {
    _errMsg(L"GetUserNameEx");
    return false;
  }
  psz = szTitle + lstrlen(szTitle);

  HANDLE htok;
  if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &htok)) {
    _errMsg(L"OpenProcessToken");
    return false;
  }
  TOKEN_STATISTICS stats;
  DWORD cb = sizeof stats;
  if (!GetTokenInformation(htok, TokenStatistics, &stats, cb, &cb)) {
    _errMsg(L"GetTokenInformation");
    return false;
  }
  wsprintf(psz, L" [0x%x-%x]",
           stats.AuthenticationId.HighPart,
           stats.AuthenticationId.LowPart);
  CloseHandle(htok);
  SetWindowText(m_hwnd, szTitle);
  return true;
}

void TktViewMainWnd::_readTktCache() {
  if (m_pTktCache) {
    LsaFreeReturnBuffer(m_pTktCache);
    m_pTktCache = 0;
  }

  KERB_QUERY_TKT_CACHE_REQUEST req = {
    KerbQueryTicketCacheMessage,
    0
  };
  
  void* pRep;
  DWORD cbRep;
  NTSTATUS pkgStatus;
  NTSTATUS s = LsaCallAuthenticationPackage(m_hLSA, m_nKerbIndex,
                                            &req, sizeof req,
                                            &pRep, &cbRep, &pkgStatus);
  if (s) {
    _lsaErrMsg(L"LsaCallAuthenticationPackage", s);
    return;
  }
  if (pkgStatus) {
    _lsaErrMsg(L"KerbQueryTicketCacheMessage", pkgStatus);
    return;
  }
  m_pTktCache = reinterpret_cast<KERB_QUERY_TKT_CACHE_RESPONSE*>(pRep);
}

void TktViewMainWnd::_purgeTicketCache(int id) {
  KERB_PURGE_TKT_CACHE_REQUEST req = {
    KerbPurgeTicketCacheMessage
  };

  wstring sServerName;
  wstring sRealmName;

  switch (id) {
    case ID_FILE_PURGE_ALL:
      break;
    case ID_FILE_PURGE_BY_PRINCIPAL: {
      KERB_TICKET_CACHE_INFO* pItem = reinterpret_cast<KERB_TICKET_CACHE_INFO*>(m_pReportView->getSelectedItem());
      if (!pItem)
        return;
      try {
        // I can't seem to get this to work,
        // even when I reform the strings with NULL terminators...
        sServerName = _towstring(pItem->ServerName);
        sRealmName  = _towstring(pItem->RealmName);
        _initString(req.ServerName, const_cast<wchar_t*>(sServerName.c_str()));
        _initString(req.RealmName,  const_cast<wchar_t*>(sRealmName.c_str()));
      }
      catch (const exception& x) {
        MessageBoxA(m_hwnd, x.what(), 0, MB_ICONEXCLAMATION);
      }
      break;
     }
  }

  NTSTATUS pkgStatus;
  NTSTATUS s = LsaCallAuthenticationPackage(m_hLSA, m_nKerbIndex,
                                            &req, sizeof req,
                                            0, 0, &pkgStatus);
  if (s) {
    _lsaErrMsg(L"LsaCallAuthenticationPackage", s);
    return;
  }
  if (pkgStatus) {
    _lsaErrMsg(L"KerbPurgeTicketCacheMessage", pkgStatus);
    return;
  }
}

void TktViewMainWnd::_refresh() {
  _readTktCache();
  _updateViewFromTktCache();
}

void TktViewMainWnd::_updateViewFromTktCache() {
  m_pReportView->clear();

  try {
    for (DWORD i = 0; i < m_pTktCache->CountOfTickets; ++i) {
      KERB_TICKET_CACHE_INFO& ti = m_pTktCache->Tickets[i];
      vector<wstring> text;
      text.push_back(_towstring(ti.ServerName));
      text.push_back(_towstring(ti.RealmName));
      text.push_back(_towstring(toFILETIME(ti.StartTime)));
      text.push_back(_towstring(toFILETIME(ti.EndTime)));
      text.push_back(_towstring(toFILETIME(ti.RenewTime)));
      text.push_back(_towstring(ti.EncryptionType));
      text.push_back(_towstring(ti.TicketFlags));
      m_pReportView->append(text, &ti);
    }
  }
  catch (const exception& x) {
    MessageBoxA(m_hwnd, x.what(), 0, MB_ICONEXCLAMATION);
  }
}

BOOL TktViewMainWnd::onCreate(CREATESTRUCT* pcs) {
  if (!_setTitle())
    return FALSE;

  DataProvider* pDataProvider = new DataProvider(*this);
  if (!pDataProvider)
    return FALSE;

  m_pReportView = new ReportView(pDataProvider);
  if (!m_pReportView)
    return FALSE;

  m_pReportView->addColumn(L"Principal",       LVCFMT_LEFT, 100, true);
  m_pReportView->addColumn(L"Authority",       LVCFMT_LEFT, 75,  true);
  m_pReportView->addColumn(L"Start Time",      LVCFMT_LEFT, 125, true);
  m_pReportView->addColumn(L"End Time",        LVCFMT_LEFT, 125, true);
  m_pReportView->addColumn(L"Renew Till",      LVCFMT_LEFT, 125, true);
  m_pReportView->addColumn(L"Encryption Type", LVCFMT_LEFT, 50,  false);
  m_pReportView->addColumn(L"Flags",           LVCFMT_LEFT, 75,  true, false);

  RECT rc;
  GetClientRect(m_hwnd, &rc);
  
  if (!m_pReportView->create(m_hwnd, 1, rc))
    return FALSE;

  _refresh();
  return TRUE;
}

void TktViewMainWnd::onDestroy() {
  PostQuitMessage(0);
}

void TktViewMainWnd::onSize(UINT state, int cx, int cy) {
  if (m_pReportView) {
    RECT rc = { 0, 0, cx, cy };
    m_pReportView->resize(rc);
  }
}

void TktViewMainWnd::onCommand(int id, HWND hwndCtl, UINT codeNotify) {
  switch (id) {
  case ID_FILE_PURGE_ALL:
    _purgeTicketCache(id);
    _refresh();
    break;

  case ID_FILE_PURGE_BY_PRINCIPAL:
    _purgeTicketCache(id);
    _refresh();
    break;

  case ID_FILE_EXIT:
    PostMessage(m_hwnd, WM_CLOSE, 0, 0);
    break;
  
  case ID_VIEW_CHOOSECOLUMNS:
    if (m_pReportView->chooseColumns(GetModuleHandle(0), IDD_CHOOSE_COLUMNS))
      _updateViewFromTktCache();
    break;
  
  case ID_VIEW_REFRESH:
    _refresh();
    break;

  case ID_HELP_ABOUT:
    MessageBox(m_hwnd, L"Ticket Viewer v1.0\n\nby Keith Brown\nhttp://www.develop.com/kbrown",
                       L"About Ticket Viewer",
                       MB_ICONINFORMATION | MB_SETFOREGROUND);
    break;
  }
}

LRESULT TktViewMainWnd::onNotify(int id, NMHDR* p) {
  if (1 == id)
    return m_pReportView->onWM_NOTIFY(p);
  return 0;
}

void TktViewMainWnd::onSetFocus(HWND) {
  m_pReportView->setFocus();
}

void TktViewMainWnd::onInitMenuPopup(HMENU hMenu, UINT item, BOOL fSystemMenu) {
  if (fSystemMenu)
    return;
  switch (item) {
  case 0:
    _initFileMenuPopup(hMenu);
    break;
  }
}

void TktViewMainWnd::_initFileMenuPopup(HMENU hMenu) {
  try {
    KERB_TICKET_CACHE_INFO* pItem = reinterpret_cast<KERB_TICKET_CACHE_INFO*>(m_pReportView->getSelectedItem());
    if (pItem) {
      wstring sPrincipal = _towstring(pItem->ServerName);

      MENUITEMINFO mii;
      mii.cbSize = sizeof mii;
      mii.fMask  = MIIM_STRING | MIIM_STATE;
      mii.fState = MFS_ENABLED;

      wchar_t sz[512];
      if (sPrincipal.size() > 400)
        sPrincipal = L"selected principal";
      wsprintf(sz, L"Purge all tickets for %s", sPrincipal.c_str());
      mii.dwTypeData = sz;
      SetMenuItemInfo(hMenu, ID_FILE_PURGE_BY_PRINCIPAL, FALSE, &mii);
    }
    else {
      MENUITEMINFO mii;
      mii.cbSize = sizeof mii;
      mii.fMask  = MIIM_STATE;
      mii.fState = MFS_DISABLED;
      SetMenuItemInfo(hMenu, ID_FILE_PURGE_BY_PRINCIPAL, FALSE, &mii);
    }
  }
  catch (const exception& x) {
    MessageBoxA(m_hwnd, x.what(), 0, MB_ICONEXCLAMATION);
  }
}

///////////////////////////////////////////////////////////

static void _addTicketFlag(HWND hwndList, ULONG flags, ULONG mask, const wchar_t* pszName) {
  if (flags & mask) {
    ListBox_AddString(hwndList, pszName);
  }
}

BOOL CALLBACK TktViewMainWnd::_ticketPropertiesDlg(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  switch (msg) {
    case WM_INITDIALOG: {
      
      HWND hwndList = GetDlgItem(hwnd, 100);
      KERB_TICKET_CACHE_INFO& ti = *reinterpret_cast<KERB_TICKET_CACHE_INFO*>(lp);
      const DWORD flags = ti.TicketFlags;
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_renewable,    L"renewable");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_initial,      L"initial");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_invalid,      L"invalid");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_forwardable,  L"forwardable");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_forwarded,    L"forwarded");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_proxiable,    L"proxiable");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_proxy,        L"proxy");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_may_postdate, L"may_postdate");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_postdated,    L"postdated");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_pre_authent,  L"pre_authent");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_hw_authent,   L"hw_authent");
      _addTicketFlag(hwndList, flags, KERB_TICKET_FLAGS_ok_as_delegate, L"ok_as_delegate");
      return TRUE;
    }
    case WM_COMMAND:
      switch (LOWORD(wp)) {
      case IDOK:
      case IDCANCEL:
        EndDialog(hwnd, IDOK);
        return TRUE;
      }
      break;
  }
  return FALSE;
}

