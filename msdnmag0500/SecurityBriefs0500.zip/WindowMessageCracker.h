// WindowMessageCracker.h
#pragma once

#include <windowsx.h>

template <typename T>
struct WindowMessageCracker {
  static T& _this(HWND hwnd) {
    return *reinterpret_cast<T*>(GetWindowLongPtr(hwnd, GWLP_USERDATA));
  }
  static BOOL _crack_WM_CREATE(HWND hwnd, LPCREATESTRUCT p) {
    _this(hwnd).setHwnd(hwnd);
    return _this(hwnd).onCreate(p);
  }
  static void _crack_WM_DESTROY(HWND hwnd) {
    _this(hwnd).onDestroy();
  }
  static void _crack_WM_SIZE(HWND hwnd, UINT state, int cx, int cy) {
    _this(hwnd).onSize(state, cx, cy);
  }
  static void _crack_WM_COMMAND(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify) {
    _this(hwnd).onCommand(id, hwndCtl, codeNotify);
  }
  static LRESULT _crack_WM_NOTIFY(HWND hwnd, int id, NMHDR* p) {
    return _this(hwnd).onNotify(id, p);
  }
  static void _crack_WM_SETFOCUS(HWND hwnd, HWND hwndOldFocus) {
    _this(hwnd).onSetFocus(hwndOldFocus);
  }
  static void _crack_WM_INITMENUPOPUP(HWND hwnd, HMENU hMenu, UINT item, BOOL fSystemMenu) {
    _this(hwnd).onInitMenuPopup(hMenu, item, fSystemMenu);
  }
};

#define BEGIN_CRACK(c) \
if (WM_CREATE == msg) { \
  LONG_PTR p = reinterpret_cast<LONG_PTR>(reinterpret_cast<CREATESTRUCT*>(lp)->lpCreateParams); \
  SetWindowLongPtr(hwnd, GWLP_USERDATA, p); \
} \
typedef WindowMessageCracker<c> __cracker; \
switch(msg) {

#define END_CRACK() }

#define CRACK_MSG(msg) case (msg): return HANDLE_##msg((hwnd), (wp), (lp), (__cracker::_crack_##msg));
