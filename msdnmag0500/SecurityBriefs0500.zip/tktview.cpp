#include "precomp.h"
#include "TktViewMainWnd.h"
#include "resource.h"
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "secur32.lib")

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {
  INITCOMMONCONTROLSEX iccex = { sizeof iccex, ICC_LISTVIEW_CLASSES };
  if (!InitCommonControlsEx(&iccex))
    return -1;
  
  if (!TktViewMainWnd::registerClass())
    return -1;

  TktViewMainWnd* pTktViewMainWnd = TktViewMainWnd::create(nCmdShow);
  if (!pTktViewMainWnd)
    return -1;

  HACCEL hAccel = LoadAccelerators(hInst, MAKEINTRESOURCE(IDR_TKTVIEW_ACCEL));

  MSG msg;
  while (GetMessage(&msg, 0, 0, 0)) {
    if (!TranslateAccelerator(pTktViewMainWnd->m_hwnd, hAccel, &msg))
      TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  return msg.wParam;
}
