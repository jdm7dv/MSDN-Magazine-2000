#pragma once

class ReportView;

struct TktViewMainWnd {
  TktViewMainWnd()
    : m_hwnd(0),
      m_pReportView(0),
      m_pTktCache(0),
      m_hLSA(0),
      m_nKerbIndex(0)
  {}

  ~TktViewMainWnd();

  static bool registerClass();
  static TktViewMainWnd* create(int nCmdShow);
  static LRESULT CALLBACK wndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
  void setHwnd(HWND hwnd) { m_hwnd = hwnd; }

  static BOOL CALLBACK _ticketPropertiesDlg(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);

  BOOL onCreate(CREATESTRUCT* pcs);
  void onDestroy();
  void onSize(UINT state, int cx, int cy);
  void onCommand(int id, HWND hwndCtl, UINT codeNotify);
  LRESULT onNotify(int id, NMHDR* p);
  void onSetFocus(HWND);
  void onInitMenuPopup(HMENU hMenu, UINT item, BOOL fSystemMenu);

  bool _connectToLSA();
  bool _setTitle();
  void _refresh();
  void _readTktCache();
  void _purgeTicketCache(int id);
  void _updateViewFromTktCache();
  void _initFileMenuPopup(HMENU hMenu);

  HWND                           m_hwnd;
  ReportView*                    m_pReportView;
  KERB_QUERY_TKT_CACHE_RESPONSE* m_pTktCache;
  HANDLE                         m_hLSA;
  ULONG                          m_nKerbIndex;
};
