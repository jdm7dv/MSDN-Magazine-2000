// MiscUtils.h
#pragma once
#include <string>
#include <algorithm>
#include <exception>

inline void _initString(UNICODE_STRING& us, wchar_t* psz) {
  if (psz) {
    USHORT cch = wcslen(psz);
    us.Length = cch * sizeof(wchar_t);
    us.MaximumLength = (cch + 1) * sizeof(wchar_t);
    us.Buffer = psz;
  }
  else {
    us.Length = us.MaximumLength = 0;
    us.Buffer = 0;
  }
}

inline void _initString(LSA_STRING& s, char* psz) {
  if (psz) {
    USHORT cch = lstrlenA(psz);
    s.Length = cch;
    s.MaximumLength = cch + 1;
    s.Buffer = psz;
  }
  else {
    s.Length = s.MaximumLength = 0;
    s.Buffer = 0;
  }
}

inline void _lookupErrorMsg(wchar_t* pszMsg, int cch, DWORD err) {

  DWORD grfFormat = FORMAT_MESSAGE_FROM_SYSTEM |
                    FORMAT_MESSAGE_IGNORE_INSERTS;
  if (!FormatMessage(grfFormat, 0, err, 0,
                     pszMsg, cch, 0))
    wsprintf(pszMsg, L"Unknown Error: %d (0x%08X)", err, err);
}

inline void _errMsg(const wchar_t* pszFcn, DWORD err = GetLastError()) {
  wchar_t szMsg[512];
  _lookupErrorMsg(szMsg, sizeof szMsg / sizeof *szMsg, err);
  
  wchar_t sz[1024];
  wsprintf(sz, L"%s failed: %s", pszFcn, szMsg);
  
  MessageBox(0, sz, 0, MB_ICONEXCLAMATION | MB_SETFOREGROUND);
}

inline void _lsaErrMsg(const wchar_t* pszFcn, NTSTATUS err) {
  _errMsg(pszFcn, LsaNtStatusToWinError(err));
}

inline std::wstring _towstring(const UNICODE_STRING& us) {
  const int cch = (us.Length) / sizeof(wchar_t);
  std::wstring s;
  s.reserve(cch + 1);
  s.assign(us.Buffer, us.Buffer + cch);
  s.append(1, L'\0');
  return s;
}

inline std::wstring _towstring(FILETIME gmTime) {
  // Kerberos ticket times are in GMT
  // convert to local time for convenience
  FILETIME localTime;
  if (!FileTimeToLocalFileTime(&gmTime, &localTime))
    throw exception("FileTimeToLocalFileTime failed");

  SYSTEMTIME st;
  if (!FileTimeToSystemTime(&localTime, &st))
    throw exception("FileTimeToSystemTime failed");
  wchar_t sz[80];
  wsprintf(sz, L"%02d/%02d/%04d %02d:%02d:%02d",
           st.wMonth, st.wDay,    st.wYear,
           st.wHour,  st.wMinute, st.wSecond);
  return std::wstring(sz);
}

inline std::wstring _towstring(LONG n) {
  wchar_t sz[40];
  wsprintf(sz, L"%d", n);
  return std::wstring(sz);
}

inline std::wstring _towstring(ULONG n) {
  wchar_t sz[40];
  wsprintf(sz, L"0x%08X", n);
  return std::wstring(sz);
}

inline FILETIME toFILETIME(LARGE_INTEGER li) {
  return *reinterpret_cast<FILETIME*>(&li);
}

inline int compare(const UNICODE_STRING& a, const UNICODE_STRING& b) {
  int c;
  try {
    c = lstrcmp(_towstring(a).c_str(), _towstring(b).c_str());
  }
  catch (const exception& x) {
    MessageBoxA(0, x.what(), 0, MB_ICONEXCLAMATION | MB_SETFOREGROUND);
  }
  return c;
}

inline int compare(LARGE_INTEGER a, LARGE_INTEGER b) {
  const __int64 d = *reinterpret_cast<__int64*>(&a) - *reinterpret_cast<__int64*>(&b);
  if (d < 0)
    return -1;
  else if (d > 0)
    return 1;
  return 0;
}

inline int compare(ULONG a, ULONG b) {
  return a - b;
}

inline int compare(LONG a, LONG b) {
  return a - b;
}
