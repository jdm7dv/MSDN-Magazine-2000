#include <afxwin.h>        // MFC core and standard components
#include <afxdlgs.h>       // MFC property sheets
#include <cpl.h>				// control panel definitions



