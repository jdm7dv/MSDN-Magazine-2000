// Sieve.h : Declaration of the CSieve

#ifndef __SIEVE_H_
#define __SIEVE_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSieve

class ATL_NO_VTABLE CSieve : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CSieve, &CLSID_Sieve>,
	public ISieve,
	public ICallFactory
{
public:
	CSieve()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIEVE)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSieve)
	COM_INTERFACE_ENTRY(ISieve)
	COM_INTERFACE_ENTRY(ICallFactory)
END_COM_MAP()

// ISieve
public:
	STDMETHOD(CountPrimes)(/*[in]*/ unsigned long lMax,
		/*[out]*/ unsigned long* plResult);

// ICallFactory
	STDMETHOD(CreateCall)(REFIID riid1, IUnknown* pUnk, REFIID riid2,
		IUnknown** ppv);
};

#endif //__SIEVE_H_
