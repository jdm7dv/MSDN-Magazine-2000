// Sieve.cpp : Implementation of CSieve
#include "stdafx.h"
#include "SieveServer.h"
#include "Sieve.h"
#include "ServerCallObject.h"

/////////////////////////////////////////////////////////////////////////////
// CSieve

STDMETHODIMP CSieve::CountPrimes(unsigned long lMax, unsigned long *plResult)
{
	//
	// NOTE: This method will never be called if CreateCall doesn't fail.
	//
	return E_NOTIMPL;
}

STDMETHODIMP CSieve::CreateCall (REFIID riid1, IUnknown* pUnk, REFIID riid2,
	IUnknown** ppv)
{
	//
	// Validate input parameters.
	//
	if (riid1 != IID_AsyncISieve || (pUnk != NULL && riid2 != IID_IUnknown))
		return E_INVALIDARG;

	//
	// Create a server-side call object and allow COM to aggregate it if
	// pUnk is non-NULL.
	//
	CComPolyObject<CServerCallObject>* pCallObject = NULL;
	HRESULT hr = CComPolyObject<CServerCallObject>::CreateInstance (pUnk,
		&pCallObject);

	if (FAILED (hr))
		return hr;
		
	//
	// Query the call object for the requested interface.
	//
	return pCallObject->QueryInterface (riid2, (void**) ppv);
}
