// ServerCallObject.cpp : Implementation of CServerCallObject
#include "stdafx.h"
#include "SieveServer.h"
#include "ServerCallObject.h"

/////////////////////////////////////////////////////////////////////////////
// CServerCallObject

STDMETHODIMP CServerCallObject::Begin_CountPrimes (unsigned long lMax)
{
	//
	// Make sure that a call isn't already in progress. Call objects
	// support only one outbound call at a time.
	//
	Lock ();

	if (m_bCallInProgress) {
		Unlock ();
		return (m_hResultBegin = RPC_S_CALLPENDING);
	}

	m_bCallInProgress = TRUE;
	Unlock ();

	//
	// Store the input parameter lMax.
	//
	m_lMax = lMax;

	//
	// Reset the synchronization object used to signal the stub that the
	// call has returned.
	//
	ISynchronize* pSynchronize;
	HRESULT hr = ((AsyncISieve*) this)->QueryInterface (IID_ISynchronize,
		(void**) &pSynchronize);
	ATLASSERT (SUCCEEDED (hr));

	pSynchronize->Reset ();

	//
	// Pass the buck to another thread.
	//
	if (!QueueUserWorkItem (ThreadFunc, this, WT_EXECUTEDEFAULT)) {
		m_bCallInProgress = FALSE;
		m_hResultBegin = E_OUTOFMEMORY;
		pSynchronize->Signal ();
		pSynchronize->Release ();
		return m_hResultBegin;
	}

	//
	// Clean up and return.
	//
	pSynchronize->Release ();
	return (m_hResultBegin = S_OK);
}

STDMETHODIMP CServerCallObject::Finish_CountPrimes (unsigned long* plResult)
{
	*plResult = 0;

	//
	// Do nothing if Begin_CountPrimes hasn't been called.
	//
	if (!m_bCallInProgress)
		return RPC_E_CALL_COMPLETE;

	//
	// Fail this call if Begin_CountPrimes was called but failed.
	//
	if (FAILED (m_hResultBegin))
		return m_hResultBegin;

	//
	// If the call hasn't returned, wait until it does.
	//
	ISynchronize* pSynchronize;
	HRESULT hr = ((AsyncISieve*) this)->QueryInterface (IID_ISynchronize,
		(void**) &pSynchronize);
	ATLASSERT (SUCCEEDED (hr));

	pSynchronize->Wait (0, INFINITE);
	pSynchronize->Release ();

	//
	// Return the results to the caller.
	//
	*plResult = m_lResult;
	m_bCallInProgress = FALSE;
	return m_hResultFinish;
}

/////////////////////////////////////////////////////////////////////////////
// Thread function (global scope)

DWORD WINAPI ThreadFunc (LPVOID pThreadParms)
{
	CoInitializeEx (NULL, COINIT_MULTITHREADED);

	//
	// Make a local copy of the input parameter lMax.
	//
	CServerCallObject* pServerCallObject = (CServerCallObject*) pThreadParms;
	unsigned long lMax = pServerCallObject->m_lMax;

	//
	// Count prime numbers between 2 and lMax.
	//
    ATLTRY (PBYTE pBuffer = new BYTE[lMax + 1]);

	if (pBuffer == NULL) {
		pServerCallObject->m_lResult = 0;
		pServerCallObject->m_hResultFinish = E_OUTOFMEMORY;
	}
	else {
		FillMemory (pBuffer, lMax + 1, 1);

		unsigned long lLimit = 2;
		while (lLimit * lLimit < lMax)
			lLimit++;

		for (unsigned long i=2; i<=lLimit; i++) {
			if (pBuffer[i]) {
				for (unsigned long k=i + i; k<=lMax; k+=i)
					pBuffer[k] = 0;
			}
		}

		unsigned long lCount = 0;
		for (i=2; i<=lMax; i++)
			if (pBuffer[i])
				lCount++;

		delete[] pBuffer;

		pServerCallObject->m_lResult = lCount;
		pServerCallObject->m_hResultFinish = S_OK;
	}

	//
	// Let the stub know that the call is complete.
	//
	ISynchronize* pSynchronize;
	HRESULT hr =
		((AsyncISieve*) pServerCallObject)->QueryInterface (IID_ISynchronize,
		(void**) &pSynchronize);
	ATLASSERT (SUCCEEDED (hr));

	pSynchronize->Signal ();
	pSynchronize->Release ();

	//
	// Clean up and return.
	//
	CoUninitialize ();
	return 0;
}
