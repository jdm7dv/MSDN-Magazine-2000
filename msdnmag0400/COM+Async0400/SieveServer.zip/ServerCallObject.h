// ServerCallObject.h : Declaration of the CServerCallObject

#ifndef __SERVERCALLOBJECT_H_
#define __SERVERCALLOBJECT_H_

#include "resource.h"       // main symbols

DWORD WINAPI ThreadFunc (LPVOID pThreadParms);

/////////////////////////////////////////////////////////////////////////////
// CServerCallObject

class ATL_NO_VTABLE CServerCallObject : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public AsyncISieve
{
public:
	CComPtr<IUnknown> m_spUnkInner;	// Aggregated event object's IUnknown
	unsigned long m_lMax;			// Local storage for input parameter
	unsigned long m_lResult;		// Local storage for output parameter
	HRESULT m_hResultBegin;			// HRESULT returned by Begin_CountPrimes
	HRESULT m_hResultFinish;		// HRESULT returned by Finish_CountPrimes
	BOOL m_bCallInProgress;			// TRUE = Call in progress

	CServerCallObject()
	{
		m_bCallInProgress = FALSE;
	}

DECLARE_PROTECT_FINAL_CONSTRUCT()
DECLARE_GET_CONTROLLING_UNKNOWN ()

BEGIN_COM_MAP(CServerCallObject)
	COM_INTERFACE_ENTRY(AsyncISieve)
	COM_INTERFACE_ENTRY_AUTOAGGREGATE (IID_ISynchronize, m_spUnkInner.p,
		CLSID_ManualResetEvent)
END_COM_MAP()

// AsyncISieve
public:
	STDMETHOD(Begin_CountPrimes)(/*[in]*/ unsigned long lMax);
	STDMETHOD(Finish_CountPrimes)(/*[out]*/ unsigned long* plResult);
};

#endif //__SERVERCALLOBJECT_H_
