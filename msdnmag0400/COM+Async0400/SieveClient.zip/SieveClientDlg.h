// SieveClientDlg.h : header file
//

#if !defined(AFX_SIEVECLIENTDLG_H__4AFD9055_0DB0_413B_9C2C_D6FC4F407D3D__INCLUDED_)
#define AFX_SIEVECLIENTDLG_H__4AFD9055_0DB0_413B_9C2C_D6FC4F407D3D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSieveClientDlg dialog

class CSieveClientDlg : public CDialog
{
// Construction
public:
	CSieveClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSieveClientDlg)
	enum { IDD = IDD_SIEVECLIENT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSieveClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	UINT m_nCallType;
	void DoAsyncCallWithNotification (unsigned long lMax);
	void DoAsyncCall (unsigned long lMax);
	void DoSyncCall (unsigned long lMax);
	AsyncISieve* m_pAsyncSieve;
	ISieve* m_pSieve;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSieveClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBegin();
	afx_msg void OnFinish();
	afx_msg void OnCancelCall();
	afx_msg void OnGetStatus();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg LRESULT OnCallFinished (WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIEVECLIENTDLG_H__4AFD9055_0DB0_413B_9C2C_D6FC4F407D3D__INCLUDED_)
