/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Dec 23 08:41:20 1999
 */
/* Compiler settings for D:\Wicked Code\Async\SieveServer\SieveServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ISieve = {0x3A3EE73E,0x6C2F,0x41D7,{0xB8,0x39,0x95,0xD6,0xFD,0x99,0x90,0x82}};


const IID IID_AsyncISieve = {0xCA1F5D93,0x82E5,0x4266,{0x94,0x4A,0x7C,0x45,0x82,0x8C,0x9C,0xB7}};


const IID LIBID_SIEVESERVERLib = {0x6CB09C35,0x458C,0x427B,{0xAD,0x32,0x79,0x76,0x4D,0x33,0x16,0x4F}};


const CLSID CLSID_Sieve = {0x9902B032,0x0522,0x45A0,{0x8E,0xAE,0xBB,0x8A,0x64,0xD8,0xDB,0xB2}};


#ifdef __cplusplus
}
#endif

