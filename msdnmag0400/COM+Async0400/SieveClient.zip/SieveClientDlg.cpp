// SieveClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SieveServer.h"
#include "SieveServer_i.c"
#include "CallObjectServer.h"
#include "CallObjectServer_i.c"
#include "SieveClient.h"
#include "SieveClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSieveClientDlg dialog

CSieveClientDlg::CSieveClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSieveClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSieveClientDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pAsyncSieve = NULL;
	m_pSieve = NULL;
}

void CSieveClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSieveClientDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSieveClientDlg, CDialog)
	//{{AFX_MSG_MAP(CSieveClientDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BEGIN, OnBegin)
	ON_BN_CLICKED(IDC_FINISH, OnFinish)
	ON_BN_CLICKED(IDC_CANCEL, OnCancelCall)
	ON_BN_CLICKED(IDC_STATUS, OnGetStatus)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE (WM_USER_CALL_RETURNED, OnCallFinished)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSieveClientDlg message handlers

BOOL CSieveClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	CheckDlgButton (IDC_SYNCHRONOUS, BST_CHECKED);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSieveClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CSieveClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSieveClientDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	if (m_pSieve != NULL) {
		m_pSieve->Release ();
		m_pSieve = NULL;
	}	

	if (m_pAsyncSieve != NULL) {
		m_pAsyncSieve->Release ();
		m_pAsyncSieve = NULL;
	}	
}

/////////////////////////////////////////////////////////////////////////////
// Click handlers for push buttons

void CSieveClientDlg::OnBegin() 
{
	unsigned long lMax = (unsigned long) GetDlgItemInt (IDC_MAX);

	if (lMax < 3) {
		MessageBox (_T ("You must enter a value greater than 2"),
			_T ("Error"));
		GetDlgItem (IDC_MAX)->SetFocus ();
		return;
	}

	if (IsDlgButtonChecked (IDC_SYNCHRONOUS)) {
		m_nCallType = IDC_SYNCHRONOUS;
		DoSyncCall (lMax);
	}
	else if (IsDlgButtonChecked (IDC_ASYNCHRONOUS)) {
		m_nCallType = IDC_ASYNCHRONOUS;
		DoAsyncCall (lMax);
	}
	else { // IDC_ASYNCNOTIFY
		m_nCallType = IDC_ASYNCNOTIFY;
		DoAsyncCallWithNotification (lMax);
	}
}

void CSieveClientDlg::OnFinish() 
{
	ASSERT (m_pAsyncSieve != NULL);
	ASSERT (m_pSieve != NULL);

	//
	// Finish the call.
	//
	unsigned long lCount;
	HRESULT hr = m_pAsyncSieve->Finish_CountPrimes (&lCount);

	m_pAsyncSieve->Release ();
	m_pAsyncSieve = NULL;
	m_pSieve->Release ();
	m_pSieve = NULL;

	//
	// Display the result if the call wasn't cancelled.
	//
	if (SUCCEEDED (hr) && lCount != 0) {
		CString string;
		string.Format (_T ("%d"), lCount);
		MessageBox (string);
	}

	//
	// Reinitialize the push buttons.
	//
	GetDlgItem (IDC_FINISH)->EnableWindow (FALSE);
	GetDlgItem (IDC_CANCEL)->EnableWindow (FALSE);
	GetDlgItem (IDC_STATUS)->EnableWindow (FALSE);
	GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
}

void CSieveClientDlg::OnCancelCall() 
{
	ASSERT (m_pAsyncSieve != NULL);
	ASSERT (m_pSieve != NULL);

	//
	// Cancel the pending method call.
	//
	ICancelMethodCalls* pCancelMethodCalls;
	HRESULT hr = m_pAsyncSieve->QueryInterface (IID_ICancelMethodCalls,
		(void**) &pCancelMethodCalls);

	ASSERT (SUCCEEDED (hr));

	if (SUCCEEDED (hr)) {
		pCancelMethodCalls->Cancel (0);
		pCancelMethodCalls->Release ();
	}

	//
	// Perform post-cancel clean-up now if no callback is expected.
	//
	if (m_nCallType == IDC_ASYNCHRONOUS) {
		unsigned long lCount;
		m_pAsyncSieve->Finish_CountPrimes (&lCount);

		m_pAsyncSieve->Release ();
		m_pAsyncSieve = NULL;
		m_pSieve->Release ();
		m_pSieve = NULL;

		GetDlgItem (IDC_FINISH)->EnableWindow (FALSE);
		GetDlgItem (IDC_CANCEL)->EnableWindow (FALSE);
		GetDlgItem (IDC_STATUS)->EnableWindow (FALSE);
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
	}
}

void CSieveClientDlg::OnGetStatus() 
{
	ASSERT (m_pAsyncSieve != NULL);

	//
	// Query the call object for an ISynchronize interface pointer.
	//
	ISynchronize* pSynchronize;
	HRESULT hr = m_pAsyncSieve->QueryInterface (IID_ISynchronize,
		(void**) &pSynchronize);

	ASSERT (SUCCEEDED (hr));

	//
	// Check the call status.
	//
	hr = pSynchronize->Wait (0, 0);
	pSynchronize->Release ();

	//
	// Display the result.
	//
	if (hr == RPC_S_CALLPENDING)
		MessageBox (_T ("Call has not returned"));
	else if (SUCCEEDED (hr))
		MessageBox (_T ("Call has returned"));
	else
		MessageBox (_T ("ISynchronize::Wait failed"), _T ("Error"));
}

/////////////////////////////////////////////////////////////////////////////
// Helper functions called to execute synchronous and asynchronous calls.

void CSieveClientDlg::DoSyncCall(unsigned long lMax)
{
	GetDlgItem (IDC_BEGIN)->EnableWindow (FALSE);

	//
	// Create a sieve object.
	//
	ISieve* pSieve;
	HRESULT	hr = ::CoCreateInstance (CLSID_Sieve, NULL,
		CLSCTX_SERVER, IID_ISieve, (void**) &pSieve);

	if (FAILED (hr)) {
		MessageBox (_T ("CoCreateInstance failed"), _T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		return;
	}

	//
	// Perform a synchronous call.
	//
	unsigned long lCount;
	hr = pSieve->CountPrimes (lMax, &lCount);
	pSieve->Release ();

	//
	// Display the result.
	//
	if (SUCCEEDED (hr)) {
		CString string;
		string.Format (_T ("%d"), lCount);
		MessageBox (string);
	}
	else
		MessageBox (_T ("ISieve::CountPrimes failed"), _T ("Error"));

	GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
}

void CSieveClientDlg::DoAsyncCall(unsigned long lMax)
{
	GetDlgItem (IDC_BEGIN)->EnableWindow (FALSE);

	//
	// Create a sieve object.
	//
	ISieve* pSieve;
	HRESULT	hr = ::CoCreateInstance (CLSID_Sieve, NULL,
		CLSCTX_SERVER, IID_ISieve, (void**) &pSieve);

	if (FAILED (hr)) {
		MessageBox (_T ("CoCreateInstance failed"), _T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		return;
	}

	//
	// Create a call object.
	//
	ICallFactory* pCallFactory;
	hr = pSieve->QueryInterface (IID_ICallFactory, (void**) &pCallFactory);

	ASSERT (SUCCEEDED (hr));

	AsyncISieve* pAsyncSieve;
	hr = pCallFactory->CreateCall (IID_AsyncISieve, NULL, IID_AsyncISieve,
		(IUnknown**) &pAsyncSieve);
	pCallFactory->Release ();

	if (FAILED (hr)) {
		MessageBox (_T ("ICallFactory::CreateCall failed"), _T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		pSieve->Release ();
		return;
	}

	//
	// Perform an asynchronous call.
	//
	hr = pAsyncSieve->Begin_CountPrimes (lMax);

	if (FAILED (hr)) {
		MessageBox (_T ("AsyncISieve::Begin_CountPrimes failed"),
			_T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		pAsyncSieve->Release ();
		pSieve->Release ();
		return;
	}

	//
	// Cache the interface pointers.
	//
	m_pAsyncSieve = pAsyncSieve;
	m_pSieve = pSieve;

	//
	// Leave the Begin button disabled, but enable the Finish, Cancel,
	// and Get Call Status buttons.
	//
	GetDlgItem (IDC_FINISH)->EnableWindow (TRUE);
	GetDlgItem (IDC_CANCEL)->EnableWindow (TRUE);
	GetDlgItem (IDC_STATUS)->EnableWindow (TRUE);
}

void CSieveClientDlg::DoAsyncCallWithNotification(unsigned long lMax)
{
	GetDlgItem (IDC_BEGIN)->EnableWindow (FALSE);

	//
	// Create a sieve object.
	//
	ISieve* pSieve;
	HRESULT	hr = ::CoCreateInstance (CLSID_Sieve, NULL,
		CLSCTX_SERVER, IID_ISieve, (void**) &pSieve);

	if (FAILED (hr)) {
		MessageBox (_T ("CoCreateInstance failed"), _T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		return;
	}

	//
	// Create a call object.
	//
	ICallObjectInit* pCallObjectInit;
	hr = CoCreateInstance (CLSID_CallNotifyObject, NULL, CLSCTX_SERVER,
		IID_ICallObjectInit, (void**) &pCallObjectInit);

	if (FAILED (hr)) {
		MessageBox (_T ("CoCreateInstance failed"), _T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		pSieve->Release ();
		return;
	}

	//
	// Initialize the call object.
	//
	ICallFactory* pCallFactory;
	hr = pSieve->QueryInterface (IID_ICallFactory, (void**) &pCallFactory);

	ASSERT (SUCCEEDED (hr));

	AsyncISieve* pAsyncSieve;
	hr = pCallObjectInit->Initialize ((unsigned int) m_hWnd,
		WM_USER_CALL_RETURNED, pCallFactory, IID_AsyncISieve, IID_AsyncISieve,
		(void**) &pAsyncSieve);

	pCallFactory->Release ();
	pCallObjectInit->Release ();

	if (FAILED (hr)) {
		MessageBox (_T ("ICallObjectInit::Initialize failed"),
			_T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		pSieve->Release ();
		return;
	}

	//
	// Perform an asynchronous call.
	//
	hr = pAsyncSieve->Begin_CountPrimes (lMax);

	if (FAILED (hr)) {
		MessageBox (_T ("AsyncISieve::Begin_CountPrimes failed"),
			_T ("Error"));
		GetDlgItem (IDC_BEGIN)->EnableWindow (TRUE);
		pAsyncSieve->Release ();
		pSieve->Release ();
		return;
	}

	//
	// Cache the interface pointers.
	//
	m_pAsyncSieve = pAsyncSieve;
	m_pSieve = pSieve;

	//
	// Enable the Cancel button.
	//
	GetDlgItem (IDC_CANCEL)->EnableWindow (TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// Message handler used for call completion notifications

LRESULT CSieveClientDlg::OnCallFinished (WPARAM wParam, LPARAM lParam)
{
	OnFinish ();
	return 0;
}
