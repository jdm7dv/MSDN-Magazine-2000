/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Dec 23 08:41:20 1999
 */
/* Compiler settings for D:\Wicked Code\Async\SieveServer\SieveServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SieveServer_h__
#define __SieveServer_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ISieve_FWD_DEFINED__
#define __ISieve_FWD_DEFINED__
typedef interface ISieve ISieve;
#endif 	/* __ISieve_FWD_DEFINED__ */


#ifndef __AsyncISieve_FWD_DEFINED__
#define __AsyncISieve_FWD_DEFINED__
typedef interface AsyncISieve AsyncISieve;
#endif 	/* __AsyncISieve_FWD_DEFINED__ */


#ifndef __Sieve_FWD_DEFINED__
#define __Sieve_FWD_DEFINED__

#ifdef __cplusplus
typedef class Sieve Sieve;
#else
typedef struct Sieve Sieve;
#endif /* __cplusplus */

#endif 	/* __Sieve_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ISieve_INTERFACE_DEFINED__
#define __ISieve_INTERFACE_DEFINED__

/* interface ISieve */
/* [unique][helpstring][async_uuid][uuid][object] */ 


EXTERN_C const IID IID_ISieve;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("3A3EE73E-6C2F-41D7-B839-95D6FD999082")
    ISieve : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE CountPrimes( 
            /* [in] */ unsigned long lMax,
            /* [out] */ unsigned long __RPC_FAR *plResult) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISieveVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISieve __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISieve __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISieve __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CountPrimes )( 
            ISieve __RPC_FAR * This,
            /* [in] */ unsigned long lMax,
            /* [out] */ unsigned long __RPC_FAR *plResult);
        
        END_INTERFACE
    } ISieveVtbl;

    interface ISieve
    {
        CONST_VTBL struct ISieveVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISieve_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISieve_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISieve_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISieve_CountPrimes(This,lMax,plResult)	\
    (This)->lpVtbl -> CountPrimes(This,lMax,plResult)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE ISieve_CountPrimes_Proxy( 
    ISieve __RPC_FAR * This,
    /* [in] */ unsigned long lMax,
    /* [out] */ unsigned long __RPC_FAR *plResult);


void __RPC_STUB ISieve_CountPrimes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISieve_INTERFACE_DEFINED__ */


#ifndef __AsyncISieve_INTERFACE_DEFINED__
#define __AsyncISieve_INTERFACE_DEFINED__

/* interface AsyncISieve */
/* [uuid][object][helpstring][unique] */ 


EXTERN_C const IID IID_AsyncISieve;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("CA1F5D93-82E5-4266-944A-7C45828C9CB7")
    AsyncISieve : public IUnknown
    {
    public:
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Begin_CountPrimes( 
            /* [in] */ unsigned long lMax) = 0;
        
        virtual /* [helpstring] */ HRESULT STDMETHODCALLTYPE Finish_CountPrimes( 
            /* [out] */ unsigned long __RPC_FAR *plResult) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct AsyncISieveVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            AsyncISieve __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            AsyncISieve __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            AsyncISieve __RPC_FAR * This);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Begin_CountPrimes )( 
            AsyncISieve __RPC_FAR * This,
            /* [in] */ unsigned long lMax);
        
        /* [helpstring] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Finish_CountPrimes )( 
            AsyncISieve __RPC_FAR * This,
            /* [out] */ unsigned long __RPC_FAR *plResult);
        
        END_INTERFACE
    } AsyncISieveVtbl;

    interface AsyncISieve
    {
        CONST_VTBL struct AsyncISieveVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define AsyncISieve_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define AsyncISieve_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define AsyncISieve_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define AsyncISieve_Begin_CountPrimes(This,lMax)	\
    (This)->lpVtbl -> Begin_CountPrimes(This,lMax)

#define AsyncISieve_Finish_CountPrimes(This,plResult)	\
    (This)->lpVtbl -> Finish_CountPrimes(This,plResult)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring] */ HRESULT STDMETHODCALLTYPE AsyncISieve_Begin_CountPrimes_Proxy( 
    AsyncISieve __RPC_FAR * This,
    /* [in] */ unsigned long lMax);


void __RPC_STUB AsyncISieve_Begin_CountPrimes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring] */ HRESULT STDMETHODCALLTYPE AsyncISieve_Finish_CountPrimes_Proxy( 
    AsyncISieve __RPC_FAR * This,
    /* [out] */ unsigned long __RPC_FAR *plResult);


void __RPC_STUB AsyncISieve_Finish_CountPrimes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __AsyncISieve_INTERFACE_DEFINED__ */



#ifndef __SIEVESERVERLib_LIBRARY_DEFINED__
#define __SIEVESERVERLib_LIBRARY_DEFINED__

/* library SIEVESERVERLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SIEVESERVERLib;

EXTERN_C const CLSID CLSID_Sieve;

#ifdef __cplusplus

class DECLSPEC_UUID("9902B032-0522-45A0-8EAE-BB8A64D8DBB2")
Sieve;
#endif
#endif /* __SIEVESERVERLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
