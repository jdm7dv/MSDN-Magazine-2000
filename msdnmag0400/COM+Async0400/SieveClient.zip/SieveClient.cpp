// SieveClient.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "SieveServer.h"
#include "CallObjectServer.h"
#include "SieveClient.h"
#include "SieveClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSieveClientApp

BEGIN_MESSAGE_MAP(CSieveClientApp, CWinApp)
	//{{AFX_MSG_MAP(CSieveClientApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSieveClientApp construction

CSieveClientApp::CSieveClientApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSieveClientApp object

CSieveClientApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSieveClientApp initialization

BOOL CSieveClientApp::InitInstance()
{
	if (!AfxOleInit ()) {
		AfxMessageBox (_T ("Unable to initialize the COM libraries"));
		return FALSE;
	}

	CSieveClientDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	return FALSE;
}
