/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Dec 21 10:17:24 1999
 */
/* Compiler settings for D:\Wicked Code\Async\CallObjectServer\CallObjectServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ICallObjectInit = {0xD38F681D,0x307F,0x4559,{0x96,0xC8,0xFF,0x8B,0x75,0x97,0x12,0xA9}};


const IID LIBID_CALLOBJECTSERVERLib = {0xA6F81835,0x1098,0x4123,{0xAB,0x27,0x22,0xF9,0x8E,0xAB,0x8F,0x05}};


const CLSID CLSID_CallNotifyObject = {0x3DE3FDA5,0xA785,0x423C,{0x84,0xA5,0x45,0xA1,0x2A,0x15,0xFC,0xBD}};


#ifdef __cplusplus
}
#endif

