/*----------------------------------------------------------------------
       Bugslayer Column - April '00 MSDN Magazine - John Robbins
----------------------------------------------------------------------*/

#ifndef _RESOURCEIDS_H
#define _RESOURCEIDS_H

/*//////////////////////////////////////////////////////////////////////
                           Necessary Includes
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                          Constants & Defines
//////////////////////////////////////////////////////////////////////*/

#define IDS_LOGO                        100

#define IDS_USAGESTART                  101
#define IDS_USAGE1                      101
#define IDS_USAGE2                      102
#define IDS_USAGE3                      103
#define IDS_USAGE4                      104
#define IDS_USAGE5                      105
#define IDS_USAGE6                      106
#define IDS_USAGE7                      107
#define IDS_USAGE8                      108
#define IDS_USAGE9                      109
#define IDS_USAGE10                     110
#define IDS_USAGE11                     111
#define IDS_USAGE12                     112
#define IDS_USAGELAST                   113

#define IDS_P2MEXT                      120

#define IDS_INVALIDCMDLINE              130
#define IDS_FAILEDSYMINIT               131
#define IDS_NOOPENFILE                  132
#define IDS_NOLOADSYMBOLS               133
#define IDS_NOMODINFO                   134
#define IDS_WRONGSYMTYPE                135
#define IDS_NOOPENOUTPUT                136
#define IDS_WRITEFAILED                 137
#define IDS_FUNCENUMFAILED              138
#define IDS_NOFUNCTIONINFO              139
#define IDS_NOLINEINFO                  141


#define IDS_VB_INITSYMENG               200
#define IDS_VB_OPENINGFILE              201
#define IDS_VB_LOADINGSYMS              202
#define IDS_VB_GETMODULEINFO            203
#define IDS_VB_WRITINGHEADER            204
#define IDS_VB_STARTENUM                205
#define IDS_VBS_HASSRCLINE              206
#define IDS_VBS_ADDINGLINE              207
#define IDS_VBS_NEWRANGE                208

#define IDS_HEADERINFO                  300
#define IDS_FUNCTIONHEADER              301
#define IDS_FUNCTFORMAT                 302
#define IDS_SPACERS                     303
#define IDS_SRCHEADER                   304
#define IDS_LINEFORMAT                  305


/*//////////////////////////////////////////////////////////////////////
                                Typedefs
//////////////////////////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////////////////////////
                               Prototypes
//////////////////////////////////////////////////////////////////////*/

#endif  // _RESOURCEIDS_H


