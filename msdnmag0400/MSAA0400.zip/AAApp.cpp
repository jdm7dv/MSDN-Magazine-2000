#include <windows.h>
#include <oleacc.h>
#include <winable.h>
#include <atlbase.h>

#define WM_TARGET_WINDOW_FOUND WM_USER + 1
const char  szMainTitle[] = "Find: All Files";

// --------------------------------------------------------------------------
//
//  GetObjectName()
//
// --------------------------------------------------------------------------
UINT GetObjectName(IAccessible* pacc, VARIANT* pvarChild, LPTSTR lpszName, UINT cchName)
{
    HRESULT hr;
    BSTR bstrName;

    *lpszName = 0;
    bstrName = NULL;

    hr = pacc->get_accName(*pvarChild, &bstrName);
    
    if (SUCCEEDED(hr) && bstrName)
    {
        WideCharToMultiByte(CP_ACP, 0, bstrName, -1, lpszName, cchName, NULL, NULL);
        SysFreeString(bstrName);
    }

    return(lstrlen(lpszName));
} 

// --------------------------------------------------------------------------
//
//  GetObjectRole()
//
// --------------------------------------------------------------------------
UINT GetObjectRole(IAccessible* pacc, VARIANT* pvarChild, LPTSTR lpszRole, UINT cchRole)
{
    HRESULT hr;
    VARIANT varRetVal;

    *lpszRole = 0;

    VariantInit(&varRetVal);

    hr = pacc->get_accRole(*pvarChild, &varRetVal);
	
	if (!SUCCEEDED(hr))
        return(0);

    if (varRetVal.vt == VT_I4)
    {
        GetRoleText(varRetVal.lVal, lpszRole, cchRole);
    }
    else if (varRetVal.vt == VT_BSTR)
    {
        WideCharToMultiByte(CP_ACP, 0, varRetVal.bstrVal, -1, lpszRole,
            cchRole, NULL, NULL);
    }

    VariantClear(&varRetVal);

    return(lstrlen(lpszRole));
}

// --------------------------------------------------------------------------
//
//  GetObjectState()
//
// --------------------------------------------------------------------------
UINT GetObjectState(IAccessible* pacc, VARIANT* pvarChild, LPTSTR lpszState, UINT cchState)
{
    HRESULT hr;
    VARIANT varRetVal;

    *lpszState = 0;

    VariantInit(&varRetVal);

    hr = pacc->get_accState(*pvarChild, &varRetVal);

	if (!SUCCEEDED(hr))
        return(0);

	DWORD dwStateBit;
	int cChars = 0;
    if (varRetVal.vt == VT_I4)
	{
		// Convert state flags to comma separated list.
        for (dwStateBit = STATE_SYSTEM_UNAVAILABLE; dwStateBit < STATE_SYSTEM_ALERT_HIGH; dwStateBit <<= 1)
        {
            if (varRetVal.lVal & dwStateBit)
            {
                cChars += GetStateText(dwStateBit, lpszState + cChars, cchState - cChars);
				*(lpszState + cChars++) = ',';
            }
        }
		if(cChars > 1)
			*(lpszState + cChars - 1) = '\0';
    }
    else if (varRetVal.vt == VT_BSTR)
    {
        WideCharToMultiByte(CP_ACP, 0, varRetVal.bstrVal, -1, lpszState,
            cchState, NULL, NULL);
    }

    VariantClear(&varRetVal);

    return(lstrlen(lpszState));
}


// --------------------------------------------------------------------------
//
//  GetObjectClass()
//
//  This gets the Class of an object.
//
// --------------------------------------------------------------------------
UINT GetObjectClass(IAccessible* pacc, LPTSTR lpszClass, UINT cchClass)
{
	HWND hWnd;
	if(S_OK == WindowFromAccessibleObject(pacc,  &hWnd))
	{
		if(hWnd)
			GetClassName(hWnd, lpszClass, cchClass);
		else
			strcpy(lpszClass, "No window");
	}

	return 1;
}
// --------------------------------------------------------------------------
//
//  FindChild()
//
//  Finds the child
//
// --------------------------------------------------------------------------

BOOL FindChild (IAccessible* paccParent, LPSTR szName, LPSTR szRole, LPSTR szClass, IAccessible** paccChild, VARIANT* pvarChild)
{

	HRESULT hr;
	long numChildren;
	unsigned long numFetched;
	VARIANT varChild;
	int index;
	IAccessible* pCAcc = NULL;
	IEnumVARIANT* pEnum = NULL;
	IDispatch* pDisp = NULL;
	BOOL found = false;
	char szObjName[256], szObjRole[256], szObjClass[256], szObjState[256];

	//Get the IEnumVARIANT interface
	hr = paccParent -> QueryInterface(IID_IEnumVARIANT, (PVOID*) & pEnum);

	if(pEnum)
		pEnum -> Reset();

	// Get child count
	paccParent -> get_accChildCount(&numChildren);
	
	for(index = 1; index <= numChildren && !found; index++)
	{
		pCAcc = NULL;
		
		// Get next child
		if (pEnum)
			hr = pEnum -> Next(1, &varChild, &numFetched);	
		else
		{
			varChild.vt = VT_I4;
			varChild.lVal = index;
		}

		// Get IDispatch interface for the child
		if (varChild.vt == VT_I4)
		{
			pDisp = NULL;
			hr = paccParent -> get_accChild(varChild, &pDisp);
		}
		else
			pDisp = varChild.pdispVal;

		// Get IAccessible interface for the child
		if (pDisp)
		{
			hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
			hr = pDisp->Release();
		}

		// Get information about the child
		if(pCAcc)
		{
			VariantInit(&varChild);
			varChild.vt = VT_I4;
			varChild.lVal = CHILDID_SELF;

			*paccChild = pCAcc;
		}
		else
			*paccChild = paccParent;

		// Skip invisible and unavailable objects and their children
		GetObjectState(*paccChild, &varChild, szObjState, sizeof(szObjState));
		if(NULL != strstr(szObjState, "unavailable"))
		{
			if(pCAcc)
				pCAcc->Release();
			continue;
		}

		GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));
		GetObjectRole(*paccChild, &varChild, szObjRole, sizeof(szObjRole));
		GetObjectClass(*paccChild, szObjClass, sizeof(szObjClass));

		if ((!szName || !strcmp(szName, szObjName)) && (!szRole || !strcmp(szRole, szObjRole)) && (!szClass || !strcmp(szClass, szObjClass)))
		{
			found = true;
			*pvarChild = varChild;
			break;
			
		}
		if(!found && pCAcc)
		{
			// Go deeper
			found = FindChild(pCAcc, szName, szRole, szClass, paccChild, pvarChild);
			if(*paccChild != pCAcc)
				pCAcc->Release();
		}
	}

	// Clean up
	if(pEnum)
		pEnum -> Release();

	return found;
}


// --------------------------------------------------------------------------
//
//  WinCreateNotifyProc()
//
// --------------------------------------------------------------------------
void CALLBACK WinCreateNotifyProc
(
    HWINEVENTHOOK  hEvent,
    DWORD   event,
    HWND    hwndMsg,
    LONG    idObject,
    LONG    idChild,
    DWORD   idThread,
    DWORD   dwmsEventTime
)
{

	if( event != EVENT_OBJECT_CREATE)
		return;

	char bufferName[256];
	IAccessible *pacc=NULL;
	VARIANT varChild;
    VariantInit(&varChild);
	HRESULT hr= AccessibleObjectFromEvent(hwndMsg, idObject, idChild, &pacc, &varChild);

	if(!SUCCEEDED(hr))
	{
		VariantClear(&varChild);
		return;
	}

	GetObjectName(pacc, &varChild, bufferName, sizeof(bufferName));
	if(strstr(bufferName, szMainTitle))
		PostThreadMessage(GetCurrentThreadId(), WM_TARGET_WINDOW_FOUND, 0, 0);
	
	return;
}

int FAR PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
	HWINEVENTHOOK  hEventHook = NULL;
	HWND hWndMainWindow;
	IAccessible *paccMainWindow = NULL;
	HRESULT hr;

	IAccessible*	paccControl = NULL;
	VARIANT			varControl;

	CoInitialize(NULL);

	if(NULL == (hWndMainWindow = FindWindow(NULL, szMainTitle)))
	{
		hEventHook = SetWinEventHook(
			EVENT_MIN,											// eventMin ID
			EVENT_MAX,											// eventMax ID
			NULL,												// always NULL for outprocess hook
			WinCreateNotifyProc,								// call back function
			0,													// idProcess
			0,													// idThread 
			WINEVENT_SKIPOWNPROCESS | WINEVENT_OUTOFCONTEXT);	// always the same for outproc hook
	}
	else
		PostThreadMessage(GetCurrentThreadId(), WM_TARGET_WINDOW_FOUND, 0, 0);
	
	MSG msg;
	while (GetMessage (&msg, NULL, 0, 0) )
	{

		if(msg.message == WM_TARGET_WINDOW_FOUND)
		{
			if(hEventHook)
			{
				UnhookWinEvent(hEventHook);
				hWndMainWindow = FindWindow(NULL, szMainTitle);
			}

			// Bring the window to foreground
			SetForegroundWindow(hWndMainWindow);
			
			if(S_OK == (hr = AccessibleObjectFromWindow(hWndMainWindow, OBJID_WINDOW, IID_IAccessible,(void**)&paccMainWindow)))
			{
				// Set Containing text:
				if(1 == FindChild (paccMainWindow, "Containing text:", "editable text", "Edit", &paccControl, &varControl))
				{
					hr = paccControl->put_accValue(varControl, CComBSTR("My Text"));
					paccControl->Release();
					VariantClear(&varControl);
				}

				// Set Named:
				if(1 == FindChild (paccMainWindow, "Named:", "window", "ComboBox", &paccControl, &varControl))
				{

					HWND hWnd;
					WindowFromAccessibleObject(paccControl, &hWnd);
					SendMessage(hWnd, WM_SETTEXT, 0, (LPARAM)"MyFile.cpp");
					paccControl->Release();
					VariantClear(&varControl);
				}

				// Click the Find Now button
				if(1 == FindChild (paccMainWindow, "Find Now", "push button", "Button", &paccControl, &varControl))
				{
					hr = paccControl->accDoDefaultAction(varControl);
					paccControl->Release();
					VariantClear(&varControl);
				}

				paccMainWindow->Release();
			}


			MessageBox(NULL, "Click OK to finish the demo", "That's all folks", MB_OK);

			// ... and press Alt+F4 to close thew window
			INPUT input[4];	
			memset(input, 0, sizeof(input));

			input[0].type = input[1].type = input[2].type = input[3].type = INPUT_KEYBOARD;
			input[0].ki.wVk  = input[2].ki.wVk = VK_MENU;
			input[1].ki.wVk  = input[3].ki.wVk = VK_F4;

			// Then release it. THIS IS IMPORTANT
			input[2].ki.dwFlags = input[3].ki.dwFlags = KEYEVENTF_KEYUP;

			SendInput(4, input, sizeof(INPUT));

			
			return 1;
		}

		TranslateMessage (&msg);
		DispatchMessage (&msg);
	}

	return 0;
}


